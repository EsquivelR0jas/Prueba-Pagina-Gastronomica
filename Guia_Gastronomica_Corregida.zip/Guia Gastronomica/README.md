# Guía Gastronómica de Cañas

Proyecto académico de Desarrollo Web.

## Estructura
- `html/`: páginas del sitio.
- `css/styles.css`: estilos.
- `js/script.js`: navegación móvil, animaciones y formulario.
- `IMG/`: imágenes y recursos gráficos.

## Publicación en Vercel
Configura `html` como directorio raíz si deseas mantener las rutas de navegación actuales. Si Vercel publica la carpeta del proyecto completa, configura las rutas de entrada o mueve los archivos HTML al directorio raíz y ajusta las referencias. Prueba todos los enlaces después de publicar.

## Importante
Las imágenes de platillos son ilustrativas. No se presentan precios como oficiales. El formulario abre la aplicación de correo del visitante y no envía datos a un servidor automáticamente. Los datos de Soda Central están marcados como pendientes de verificación.
