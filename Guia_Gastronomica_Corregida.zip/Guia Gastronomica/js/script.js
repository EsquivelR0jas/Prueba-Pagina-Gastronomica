/* Guía Gastronómica de Cañas — JavaScript principal */
document.addEventListener("DOMContentLoaded", () => {
  // Menú móvil accesible
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const abierto = !nav.classList.contains("mostrar");
      nav.classList.toggle("mostrar", abierto);
      toggle.setAttribute("aria-expanded", String(abierto));
      toggle.setAttribute("aria-label", abierto ? "Cerrar menú de navegación" : "Abrir menú de navegación");
      const icono = toggle.querySelector("i");
      if (icono) icono.className = abierto ? "fa-solid fa-xmark" : "fa-solid fa-bars";
    });
    nav.querySelectorAll("a").forEach(enlace => enlace.addEventListener("click", () => {
      nav.classList.remove("mostrar");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", "Abrir menú de navegación");
      const icono = toggle.querySelector("i");
      if (icono) icono.className = "fa-solid fa-bars";
    }));
  }

  // Fecha/hora opcional
  const fechaHora = document.getElementById("fecha-hora");
  const actualizarFechaHora = () => {
    if (!fechaHora) return;
    const ahora = new Date();
    fechaHora.textContent = `${ahora.toLocaleDateString("es-CR")} | ${ahora.toLocaleTimeString("es-CR")}`;
  };
  if (fechaHora) { actualizarFechaHora(); window.setInterval(actualizarFechaHora, 1000); }

  // Desplazamiento suave para anclas existentes
  document.querySelectorAll('a[href^="#"]').forEach(enlace => {
    enlace.addEventListener("click", evento => {
      const destino = enlace.getAttribute("href");
      if (!destino || destino === "#") return;
      const elemento = document.getElementById(destino.slice(1));
      if (elemento) { evento.preventDefault(); elemento.scrollIntoView({ behavior: "smooth", block: "start" }); }
    });
  });

  // Botón volver arriba
  const arriba = document.querySelector(".volver-arriba");
  if (arriba) {
    const actualizar = () => arriba.classList.toggle("mostrar", window.scrollY > 400);
    window.addEventListener("scroll", actualizar, { passive: true }); actualizar();
    arriba.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  }

  // Animación de tarjetas; el contenido permanece visible si no existe IntersectionObserver
  const tarjetas = document.querySelectorAll(".restaurante-card, .lugar-card, .categoria-card, .menu-card");
  if ("IntersectionObserver" in window) {
    const observador = new IntersectionObserver((entradas, obs) => entradas.forEach(entrada => {
      if (entrada.isIntersecting) {
        entrada.target.classList.add("visible", "tarjeta-visible");
        obs.unobserve(entrada.target);
      }
    }), { threshold: 0.12 });
    tarjetas.forEach(tarjeta => observador.observe(tarjeta));
  }

  // Año automático: admite los dos identificadores usados en las páginas
  document.querySelectorAll(".anio-actual, #anio").forEach(el => el.textContent = new Date().getFullYear());

  // Formulario: prepara un correo en la aplicación de correo del usuario.
  // No afirma que se envió hasta que el usuario lo envíe desde esa aplicación.
  const formulario = document.querySelector("#formulario-contacto");
  if (formulario) {
    formulario.addEventListener("submit", evento => {
      evento.preventDefault();
      if (!formulario.reportValidity()) return;
      const nombre = document.querySelector("#nombre")?.value.trim() || "";
      const correo = document.querySelector("#correo")?.value.trim() || "";
      const asunto = document.querySelector("#asunto")?.value.trim() || "Consulta desde la Guía Gastronómica de Cañas";
      const mensaje = document.querySelector("#mensaje")?.value.trim() || "";
      const cuerpo = `Nombre: ${nombre}\nCorreo de contacto: ${correo}\n\nMensaje:\n${mensaje}`;
      const mailto = `mailto:guiagastronomicacanas@gmail.com?subject=${encodeURIComponent(asunto)}&body=${encodeURIComponent(cuerpo)}`;
      const aviso = document.getElementById("estado-formulario");
      if (aviso) aviso.textContent = "Se abrirá tu aplicación de correo para que revises y envíes el mensaje. El sitio no lo envía automáticamente.";
      window.location.href = mailto;
    });
  }
});
